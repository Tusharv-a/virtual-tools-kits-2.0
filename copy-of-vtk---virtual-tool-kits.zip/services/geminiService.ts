
/**
 * Local Hardware Analysis Engine (Offline Replacement for Gemini)
 * Analyzes device specifications locally to provide optimization tips.
 */
export const getDeviceOptimizationTips = async (specs: any) => {
  // Simulate a small delay for "analysis" feel
  await new Promise(resolve => setTimeout(resolve, 800));

  const tips = [];

  // Logic based on RAM
  if (specs.memory && specs.memory < 6) {
    tips.push({
      title: "Memory Tuning",
      description: "Low RAM detected. Enable 'Suspend Execution of Cached Apps' in Developer Options to improve multitasking."
    });
  } else {
    tips.push({
      title: "RAM Efficiency",
      description: "Ample memory available. Use 'Memory Extension' or 'Virtual RAM' sparingly to avoid storage wear."
    });
  }

  // Logic based on CPU Cores
  if (specs.cores && specs.cores >= 8) {
    tips.push({
      title: "Performance Profile",
      description: "Multi-core CPU detected. Use 'Game Mode' to prioritize high-performance cores for demanding applications."
    });
  } else {
    tips.push({
      title: "CPU Preservation",
      description: "Avoid heavy background tasks while gaming to prevent thermal throttling on mid-range chipsets."
    });
  }

  // Logic based on Display
  if (specs.pixelRatio && specs.pixelRatio >= 3) {
    tips.push({
      title: "Display Scaling",
      description: "High-resolution display detected. Lower the rendering resolution to 1080p in settings to save up to 15% battery."
    });
  } else {
    tips.push({
      title: "Visual Smoothness",
      description: "Standard DPI detected. Ensure 'Force 4x MSAA' is disabled to maintain stable frame rates in UI animations."
    });
  }

  // General Offline Tip
  tips.push({
    title: "Storage Health",
    description: "Keep at least 10% of your UFS storage free to allow the controller to perform efficient wear leveling."
  });

  return tips.slice(0, 3);
};
